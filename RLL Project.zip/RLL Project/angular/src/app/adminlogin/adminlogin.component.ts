import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  name:string;
  password:string;

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
 login()
 {
      if(((this.name=='admin')||(this.name=='ADMIN'))&&((this.password=='admin')||(this.password=='ADMIN'))) {
        this.router.navigate(['/admin']);        
      } else {
        alert('Incorrect Login Details');
      }

 }
}
