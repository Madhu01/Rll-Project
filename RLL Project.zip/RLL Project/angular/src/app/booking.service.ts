import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Booking } from './booking';


@Injectable({
  providedIn: 'root'
})
export class BookingService {

  private basePath = 'http://localhost:9040/rest/booking';

  constructor(private http: HttpClient) { }


  getAllBookings(): Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.basePath}/bookingD`);
  }

  deleteOneBooking(empid: number): Observable<any> {
    return this.http.delete(`${this.basePath}/remove/${empid}`, {responseType: 'text'});
  }

  createBooking(booking: Booking): Observable<any> {
    return this.http.post(`${this.basePath}/bookingsave`, booking, {responseType: 'text'});
  }

  getOneBooking(empid: number): Observable<Booking> {
    return this.http.get<Booking>(`${this.basePath}/one/${empid}`);
  }

  

}