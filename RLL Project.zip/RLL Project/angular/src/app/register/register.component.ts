import { Component, OnInit } from '@angular/core';
import { RegisterService } from './../register.service';
import { Register } from '../register';
import { Router } from '@angular/router';
@Component({
  selector: 'app-company-create',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  // form backing object
  register: Register;
  // message to ui
  message: string;

  // inject service class
  constructor(private service: RegisterService, private router: Router) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.register = new Register();
  }

  // tslint:disable-next-line: typedef
  createUser() {
    if ((this.register.name==null )||(this.register.empid==null )|| (this.register.phoneno==null )||(this.register.address==null )||(this.register.department==null )|| (this.register.password==null )){
      alert("enter data in all required(*) feilds");
    }else
    if(this.register.phoneno.toLocaleString.length==10){
  
          alert("enter 10 digit phone number");
    }
    else{
    this.service.createRegister(this.register)
    .subscribe(data => {
      this.message = data;
       // read message
      this.register = new Register(); // clear form
    }, error => {
      console.log(error);
    });

  }}
  newUser()
  {
    this.router.navigate(['/login']);
  }

}
