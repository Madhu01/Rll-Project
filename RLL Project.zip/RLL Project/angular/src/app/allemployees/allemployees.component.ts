import { Component, OnInit } from '@angular/core';
import {RegisterService} from '../register.service';
import { Register } from './../register';
import { Router } from '@angular/router';

@Component({
  selector: 'app-allfeedback',
  templateUrl: './allemployees.component.html',
  styleUrls: ['./allemployees.component.css']
})
export class AllemployeesComponent implements OnInit {
    register:Register[];
    message: string;
  constructor(private service: RegisterService, private router: Router) { }

  ngOnInit(): void {
  
  this.getAllRegister();
}
    getAllRegister() {
    return this.service.getAllRegister()
    .subscribe(
      data => {
        this.register = data;
      }, error => {
        console.log(error);
      }
      );}
    deletebooking(id: number) {
      if (confirm('Do you want to delete?')) {
        this.service.deleteOneRegister(id).subscribe(data => {
          this.message = data;
          this.getAllRegister();
        }, error => {
          console.log(error);
        });
      } else {
        this.message = '';
      }
    }
    logout()
  {
    this.router.navigate(['/adminlogin']);
  }

  
  allFeedback()
  {
    this.router.navigate(['/allfeedback']);
  }
  allbookings()
  {
    this.router.navigate(['/allbookings']);
  }
  allEmployees()
  {
    this.router.navigate(['/allemployees']);
  }

}