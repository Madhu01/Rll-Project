
import { RegisterComponent } from './register/register.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ServicesComponent } from './services/services.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { LoginComponent } from './login/login.component';
import { AllbookingsComponent } from './allbookings/allbookings.component';
import { AdminComponent } from './admin/admin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { EmployeebookingsComponent } from './employeebookings/employeebookings.component';
import { AllfeedbackComponent } from './allfeedback/allfeedback.component';
import { AllemployeesComponent } from './allemployees/allemployees.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {path: 'onebooking', component: EmployeebookingsComponent},
  {path: 'admin', component: AdminComponent},
  {path: 'adminlogin', component: AdminloginComponent},
  {path: 'feedbacks', component: FeedbackComponent},
  {path: 'aboutus', component: AboutusComponent},
  {path: 'service', component: ServicesComponent},
  {path: 'allbookings', component: AllbookingsComponent},
  {path: 'add', component: RegisterComponent},
  {path: 'allfeedback', component: AllfeedbackComponent},
  {path: 'allemployees', component: AllemployeesComponent},
  {path: 'login', component: LoginComponent},
  {path: '', redirectTo: 'login', pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
