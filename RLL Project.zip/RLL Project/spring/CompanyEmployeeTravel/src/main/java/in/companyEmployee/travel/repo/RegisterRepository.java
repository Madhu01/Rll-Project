package in.companyEmployee.travel.repo;
import org.hibernate.annotations.NamedQuery;
import org.springframework.data.jpa.repository.JpaRepository;

import in.companyEmployee.travel.model.Register;

public interface RegisterRepository extends JpaRepository<Register, Integer>
{

}
