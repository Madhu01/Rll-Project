package in.companyEmployee.travel.repo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.hibernate.annotations.NamedQuery;

import in.companyEmployee.travel.model.*;

public interface BookingRepository extends JpaRepository<Booking, Integer>{

}

