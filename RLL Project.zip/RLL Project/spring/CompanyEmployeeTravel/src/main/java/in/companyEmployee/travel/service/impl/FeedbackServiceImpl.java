package in.companyEmployee.travel.service.impl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.companyEmployee.travel.model.*;
import in.companyEmployee.travel.repo.*;
import in.companyEmployee.travel.service.*;


@Service
public class FeedbackServiceImpl  implements IFeedbackService  {
	
	@Autowired
	private FeedbackRepository repo;
	
	@Override
	public Integer saveFeedback(Feedback s) {
		s = repo.save(s);
		return s.getId();
	}

	@Override
	public List<Feedback> getAllFeedback() {
		return repo.findAll();
	}

	
}

