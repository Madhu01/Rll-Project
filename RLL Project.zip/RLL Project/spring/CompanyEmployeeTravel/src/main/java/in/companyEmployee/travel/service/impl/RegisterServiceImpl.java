package in.companyEmployee.travel.service.impl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.companyEmployee.travel.model.*;
import in.companyEmployee.travel.repo.*;
import in.companyEmployee.travel.service.*;


@Service
public class RegisterServiceImpl  implements IRegisterService  {
	
	@Autowired
	private RegisterRepository repo;
	
	@Override
	public Integer saveEmployee(Register s) {
		s = repo.save(s);
		return s.getId();
	}


	@Override
	public void deleteEmployee(Integer id) {
		repo.deleteById(id);
	}


	@Override
	public List<Register> getAllEmployee() {
		return repo.findAll();
	}

	@Override
	public Optional<Register> getOneEmployee(Integer empid) {
		return  repo.findById(empid);
	}

	@Override
	public boolean isEmployeeExist(Integer id) {
		return repo.existsById(id);
	}


}
