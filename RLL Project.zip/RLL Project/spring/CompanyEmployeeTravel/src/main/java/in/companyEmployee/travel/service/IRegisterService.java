package in.companyEmployee.travel.service;
import java.util.List;
import java.util.Optional;

import  in.companyEmployee.travel.model.*;


public interface IRegisterService {
	Integer saveEmployee(Register s);
	
	void deleteEmployee(Integer id);

	List<Register> getAllEmployee();
	Optional<Register> getOneEmployee(Integer empid);
	boolean isEmployeeExist(Integer id);
}
